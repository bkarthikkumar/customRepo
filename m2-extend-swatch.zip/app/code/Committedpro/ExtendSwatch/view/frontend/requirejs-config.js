var config = {
    config: {
        mixins: {
            'Magento_Swatches/js/swatch-renderer': {
                'Committedpro_ExtendSwatch/swatch-renderer-mixin': true
            }
        }
    }
};