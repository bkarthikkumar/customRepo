define([
    'jquery'
], function ($) {
    'use strict';

    return function (widget) {
        $.widget('mage.SwatchRenderer', widget, {
            _loadMedia: function () {
                var productId,
                    isInProductView = false;

                productId = this.element.parents('.product-item-details')
                        .find('.price-box.price-final_price').attr('data-product-id');

                if (!productId) {
                    productId = $('[name=product]').val();
                    isInProductView = productId > 0;
                }
                if (isInProductView) {
                    this._super();
                }
            }
        });
        return $.mage.SwatchRenderer;
    }
});