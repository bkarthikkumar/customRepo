require(['jquery','jquery/ui','underscore'],function($,_){
    var extendSwatchesConfig = new Array();
    $(window).load(function(){
        
        var see_columns = '<span class="see-columns"><span class="col-text">See</span><button class="two-column-button" type="button">2</button><span class="col-separator">|</span><button class="four-column-button" type="button">4</button></div>';
        $('.field.limiter:first').after(see_columns);
        
        var hover_add_cart_button = '<div class="hover-add-to-cart-div-4-cells"><button class="hover-add-to-cart" type="button" role="button" aria-hidden="true">Add</button></div>';
        $('.products-grid .product-item-info a.product-item-photo').after(hover_add_cart_button);
       
        $(document).on({
            mouseenter: function() {
                $(this).find(".hover-add-to-cart-div-4-cells").show();
                $(this).find('.swiper-button-next').show();
                $(this).find('.swiper-button-prev').show();
            },
            mouseleave: function() {
                $(this).find(".hover-add-to-cart-div-4-cells").hide();
                $(this).find('.swatch-attribute.size').hide();
                $(this).find('.swiper-button-next').hide();
                $(this).find('.swiper-button-prev').hide();
            }
        }, ".products-grid .product-item");
        
        $(".products-grid .product-item").on('click', ".hover-add-to-cart", function(){
            $(this).parent().hide();
            $(this).parent().parent().find('.swatch-attribute.size').show();
        });
        
        $(".products-grid .product-item").on('click', ".swiper-button-next", function(e){
            e.preventDefault();
            if ($(this).parent().find('.product-image-photo').hasClass('current')) {
                var prev = $(this).parent().find('.product-image-photo.current');
                if(prev.is(':last-child')) {
                    prev.removeClass('current');
                    prev.hide('slide', {direction: 'left'}, 1000);
                    var next = $(this).parent().find('.product-image-photo:first');
                    next.addClass('current');
                    next.show('slide', {direction: 'right'}, 1000);
                } else {
                    prev.next().addClass('current');
                    prev.removeClass('current');
                    prev.hide('slide', {direction: 'left'}, 1000);
                    $(this).parent().find('.product-image-photo.current').show('slide', {direction: 'right'}, 1000);
                }
            } else {
                var prev = $(this).parent().find('.product-image-photo:first');
                prev.next().addClass('current');
                prev.hide('slide', {direction: 'left'}, 1000);
                $(this).parent().find('.product-image-photo.current').show('slide', {direction: 'right'}, 1000);
            }
            return false;
        });
        
        $(".products-grid .product-item").on('click', ".swiper-button-prev", function(e){
            e.preventDefault();
            if ($(this).parent().find('.product-image-photo').hasClass('current')) {
                var prev = $(this).parent().find('.product-image-photo.current');
                if(prev.is(':first-child')) {
                    prev.removeClass('current');
                    prev.hide('slide', {direction: 'right'}, 1000);
                    var next = $(this).parent().find('.product-image-photo:last');
                    next.addClass('current');
                    next.show('slide', {direction: 'left'}, 1000);
                } else {
                    prev.prev().addClass('current');
                    prev.removeClass('current');
                    prev.hide('slide', {direction: 'right'}, 1000);
                    $(this).parent().find('.product-image-photo.current').show('slide', {direction: 'left'}, 1000);
                }
            } else {
                var prev = $(this).parent().find('.product-image-photo:first');
                prev.hide('slide', {direction: 'right'}, 1000);
                var next = $(this).parent().find('.product-image-photo:last');
                next.addClass('current');
                next.show('slide', {direction: 'left'}, 1000);
            }
            return false;
        });
        
        $(".products-grid .product-item").on('click', ".swatch-attribute.color .swatch-option", function(){
            var product_id = $(this).parent().parent().parent().parent().find('.product-item-inner [name="product"]').val();
            var attribute_id = $(this).parent().parent().attr('attribute-id');
            var option_id = $(this).attr('option-id');
            var swatchUrl = getSelectedSwatchProductUrl(product_id, attribute_id, option_id);
            loadSwatchMedia(swatchUrl, product_id, 'user');
        });
        
        $(".products-grid .product-item").on('click', ".swatch-attribute.size .swatch-option", function(){
            $(this).parent().parent().parent().parent().find('.product-item-inner .action.tocart').trigger('click');
        });
        
        rearrangeProducts(0);
        
        $(".column.main").on('click', ".two-column-button", function() {
            setCookie('see_columns', '2', 30);
            rearrangeProducts('2');
        });
        
        $(".column.main").on('click', ".four-column-button", function() {
            deleteCookie('see_columns');
            rearrangeProducts('4');
        });
        
        $('.products-grid .product-item').each(function(){
            var product_id = $(this).find('[name="product"]').val();
            var selector = '.swatch-opt-'+product_id;
            if ($(selector).find('.swatch-attribute.color').length == 0) {
                setTimeout(function(){
                    prepareSwatchMedia(selector, product_id);
                }, 100);
            } else {
                prepareSwatchMedia(selector, product_id, true);
            }
        });
    });
    
    function rearrangeProducts(column)
    {
        if (column === 0) {
            var cookie_see_columns = getCookie('see_columns');
            if (cookie_see_columns === '2') {
                column = '2';
            } else {
                column = '4';
            }
        }
        
        if (column === '2') {
            $('.four-column-button').css('font-weight','normal');
            $('.two-column-button').css('font-weight','bold');
                
            $('.page-products .products-grid .product-item').css('width','calc((100% - 6%)/2)');
            $('.page-products .product-item-info').css('width','480px');
            $('.page-products .products-grid .product-image-container').css('width','480px');
            $('.page-products .products-grid .product-image-photo').css('width','480px');
            
            $('.products-grid .hover-add-to-cart-div-4-cells').css('top','522px');
            $('.products-grid .swatch-attribute.size').css('top','509px');
        } else {
            $('.four-column-button').css('font-weight','bold');
            $('.two-column-button').css('font-weight','normal');
                
            $('.page-products .products-grid .product-item').css('width','calc((100% - 6%)/4)');
            $('.page-products .product-item-info').css('width','240px');
            $('.page-products .products-grid .product-image-container').css('width','240px');
            $('.page-products .products-grid .product-image-photo').css('width','');
            
            $('.products-grid .hover-add-to-cart-div-4-cells').css('top','235px');
            $('.products-grid .swatch-attribute.size').css('top','221px');
        }
    }
    function setCookie(name,value,days) {
        var expires = "";
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days*24*60*60*1000));
            expires = "; expires=" + date.toUTCString();
        }
        document.cookie = name + "=" + (value || "")  + expires + "; path=/";
    }
    function getCookie(name) {
        var nameEQ = name + "=";
        var ca = document.cookie.split(';');
        for(var i=0;i < ca.length;i++) {
            var c = ca[i];
            while (c.charAt(0)==' ') c = c.substring(1,c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
        }
        return null;
    }
    function deleteCookie(name) {   
        document.cookie = name+'=; expires = Thu, 01 Jan 1970 00:00:00 GMT; path=/';  
    }
    function getSelectedSwatchProductUrl(product_id, attribute_id, option_id)
    {
        var jsonOptions = jQuery('[data-role=swatch-option-'+product_id+']').data('mageSwatchRenderer').options;
        var attributes = jsonOptions.jsonConfig.attributes;
        for(var i=0; i<attributes.length; i++) {
            if (attributes[i]['id'] == attribute_id) {
                var options = attributes[i].options;
                for(var j=0; j<options.length; j++) {
                    var option = options[j];
                    if (option['id'] == option_id) {
                        var products = option['products'];
                        var swatchId = products[0];
                        var swatchUrl = jsonOptions.mediaCallback+'?product_id='+swatchId+'&isAjax=true';
                        return swatchUrl;
                    }
                }
            }
        }
    }
    function prepareSwatchMedia(selector, product_id, skip=false)
    {
        if (!skip && $(selector).find('.swatch-attribute.color').length == 0) {
                setTimeout(function(){
                    prepareSwatchMedia(selector);
                }, 100);
         } else {
            $('.swatch-opt-'+product_id+' .swatch-option.color').first().trigger('click');
            var attribute_id = $(selector).find('.swatch-attribute.color').attr('attribute-id');
            var option_id = $(selector).find('.swatch-option.color:first').attr('option-id');
            var swatchUrl = getSelectedSwatchProductUrl(product_id, attribute_id, option_id);
            loadSwatchMedia(swatchUrl, product_id, 'auto');
        }
    }
    function loadSwatchMedia(url, product_id, mode)
    {
        var productObj = $('.products-grid .product-item').find('[name="product"][value="'+product_id+'"]');
        var parentObj = productObj.parent().parent().parent().parent().parent().parent();
        if (parentObj.find('.swiper-button-next').length > 0) {
            parentObj.find('.swiper-button-next').remove();
        }
        if (parentObj.find('.swiper-button-prev').length > 0) {
            parentObj.find('.swiper-button-prev').remove();
        }
        
        var nextNav = '<div class="swiper-button-next icon-outline-next" role="button" aria-label="Next slide"> > </div>';
        var prevNav = '<div class="swiper-button-prev icon-outline-next" role="button" aria-label="Prev slide"> < </div>';
        
        $.ajax({
            url: url,
            cache: true,
            type: 'GET',
            dataType: 'json',
            success: function (output) {
                var galleries = output.gallery;
                var i = 0;
                for (var key in galleries) {
                    if (i == 0) {
                        parentObj.find('.product-image-wrapper').html('');
                    }
                    var imageUrl = galleries[key].large;
                    var image = '<img class="product-image-photo" src="'+imageUrl+'">';
                    parentObj.find('.product-image-wrapper').append(image);
                    i++;
                }

                if (i > 1) {
                    parentObj.find('.product-image-wrapper').after(nextNav);
                    parentObj.find('.product-image-wrapper').after(prevNav);
                    if (mode === 'user') {
                        parentObj.find('.swiper-button-next').show();
                        parentObj.find('.swiper-button-prev').show();
                    }
                }
            }
        });
    }
});